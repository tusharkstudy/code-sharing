import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Document} from '../document'
import { from } from 'rxjs';

@Component({
  selector: 'app-view-documents',
  templateUrl: './view-documents.component.html',
  styleUrls: ['./view-documents.component.css']
})
export class ViewDocumentsComponent implements OnInit {

  empId: string;
  document: Document;

  constructor(private route: ActivatedRoute,private router: Router,
    private employeeService: EmployeeService) { }

  ngOnInit() {
    this.document = new Document();

    this.empId = this.route.snapshot.params['empId'];
    
    this.employeeService.getEmployee(this.empId)
      .subscribe(data => {
        console.log(data)
        this.document = data;
      }, error => console.log(error));
  }

}
