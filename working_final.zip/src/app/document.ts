export class Document {
    empId: string;
    doc: string;
    active: boolean;
}