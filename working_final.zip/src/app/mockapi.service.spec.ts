import { TestBed } from '@angular/core/testing';

import { MockapiService } from './mockapi.service';

describe('MockapiService', () => {
  //let service: MockapiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    //service = TestBed.inject(MockapiService);
  });

  it('should be created', () => {
    const service: MockapiService = TestBed.get(MockapiService);
    expect(service).toBeTruthy();
  });
});
