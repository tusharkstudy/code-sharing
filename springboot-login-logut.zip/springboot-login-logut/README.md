# Spring boot backend

This project contains the login and logout functionality.
Also it contains file upload utility. 
You can change the file upload directory from properties file.  

## Development server

Run as Java application from Application.java file. 

## Code scaffolding

Always follow below call structure
Controller > Service > Repository > DB

## Build

Run `mvn clean install` to build jar file. 
Always use `mvn clean` before committing the code in git or sharing it with someone.
