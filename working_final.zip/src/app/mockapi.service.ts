import { Injectable } from '@angular/core';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MockapiService {
  mockapi: Array<object> = [
    { document: 'Aadhar card', url:'www.google.com' },
    { document: 'Pancard', url:'www.google.com' },
    { document: 'HSC marksheet', url:'www.google.com' },
    { document: 'SSC marksheet' , url:'www.google.com'},
    { document: 'Cloud Architect Certification', url:'www.google.com' }
  ];

  constructor() { }

  get() {
    return of(this.mockapi);
  }
}
